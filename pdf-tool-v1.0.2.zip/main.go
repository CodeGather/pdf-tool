package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"image"
	"image/color"
	"image/draw"
	"image/jpeg"
	"image/png"
	"io"
	"log"
	"os"
	"path/filepath"
	"regexp"
	"runtime"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/gen2brain/go-fitz"
	tiff "github.com/hhrutter/tiff"
	"github.com/pdfcpu/pdfcpu/pkg/api"
	"github.com/pdfcpu/pdfcpu/pkg/filter"
	"github.com/pdfcpu/pdfcpu/pkg/pdfcpu"
	"github.com/pdfcpu/pdfcpu/pkg/pdfcpu/model"
	"github.com/pdfcpu/pdfcpu/pkg/pdfcpu/types"
)

var debugLogsEnabled bool
var imageMetaEnabled bool
var imageMetaJSONEnabled bool
var globalImageMetaCollector *imageMetaCollector

type imageMetaCollector struct {
	mu         sync.Mutex
	enabled    bool
	jsonOutput bool
	records    []imageMetaRecord
}

func newImageMetaCollector(enabled, jsonOutput bool) *imageMetaCollector {
	return &imageMetaCollector{enabled: enabled, jsonOutput: jsonOutput}
}

func (c *imageMetaCollector) add(meta imageMetaRecord) {
	if c == nil || !c.enabled {
		return
	}
	c.mu.Lock()
	c.records = append(c.records, meta)
	c.mu.Unlock()
}

func (c *imageMetaCollector) flush() {
	if c == nil || !c.enabled {
		return
	}
	c.mu.Lock()
	defer c.mu.Unlock()

	if c.jsonOutput {
		data, err := json.MarshalIndent(c.records, "", "  ")
		if err != nil {
			fmt.Fprintf(os.Stderr, "image meta marshal error: %v\n", err)
			return
		}
		fmt.Fprintln(os.Stdout, string(data))
		return
	}

	var builder strings.Builder
	for _, meta := range c.records {
		if meta.Time != "" {
			builder.WriteString(fmt.Sprintf("[image] page=%d source=%s object=%d index=%d size=%dx%d time=%s path=%s\n", meta.Page, meta.Source, meta.Object, meta.Index, meta.Width, meta.Height, meta.Time, meta.Path))
			continue
		}
		builder.WriteString(fmt.Sprintf("[image] page=%d source=%s object=%d index=%d size=%dx%d path=%s\n", meta.Page, meta.Source, meta.Object, meta.Index, meta.Width, meta.Height, meta.Path))
	}
	fmt.Fprint(os.Stdout, builder.String())
}

type imageMetaRecord struct {
	Type   string `json:"type"`
	Source string `json:"source"`
	Page   int    `json:"page"`
	Object int    `json:"object,omitempty"`
	Index  int    `json:"index,omitempty"`
	Width  int    `json:"width"`
	Height int    `json:"height"`
	Ext    string `json:"ext,omitempty"`
	Time   string `json:"time,omitempty"`
	Path   string `json:"path,omitempty"`
}

func main() {
	inputFile := flag.String("i", "input.pdf", "输入 PDF 文件")
	outputDir := flag.String("o", "output", "输出目录")
	format := flag.String("f", "png", "输出图片格式：png 或 jpg")
	dpi := flag.Float64("dpi", 300, "渲染 DPI")
	mergeEnabled := flag.Bool("merge", false, "合并 PDF 文件")
	mergeInputDir := flag.String("merge-dir", "", "待合并 PDF 所在目录")
	mergeInputList := flag.String("merge-inputs", "", "逗号分隔的待合并 PDF 文件列表")
	mergeGlob := flag.String("merge-glob", "*.pdf", "合并模式下的文件匹配模式")
	mergeChunkSize := flag.Int("merge-chunk-size", 50, "合并模式下每批处理的 PDF 数量")
	mergeDivider := flag.Bool("merge-divider", false, "在合并文件之间插入分隔页")
	progressEnabled := flag.Bool("p", false, "打印合并进度 0-100")
	logEnabled := flag.Bool("log", false, "打印调试日志")
	flag.BoolVar(logEnabled, "l", false, "打印调试日志")
	metaEnabled := flag.Bool("meta", false, "打印图片宽高信息")
	flag.BoolVar(metaEnabled, "m", false, "打印图片宽高信息")
	metaJSONEnabled := flag.Bool("meta-json", false, "以 JSON 形式打印图片宽高信息")
	flag.BoolVar(metaJSONEnabled, "m-json", false, "以 JSON 形式打印图片宽高信息")
	timing := flag.Bool("timing", false, "打印每个阶段的耗时信息")
	flag.BoolVar(timing, "t", false, "打印每个阶段的耗时信息")
	flag.Usage = func() {
		fmt.Fprintf(flag.CommandLine.Output(), "用法：%s [参数]\n", os.Args[0])
		flag.PrintDefaults()
		fmt.Fprintln(flag.CommandLine.Output())
		fmt.Fprintln(flag.CommandLine.Output(), "示例：")
		fmt.Fprintln(flag.CommandLine.Output(), "  cd /path/to/pdf-tool")
		fmt.Fprintln(flag.CommandLine.Output(), "  go build -o pdf-tool .")
		fmt.Fprintln(flag.CommandLine.Output(), "  ./pdf-tool -i input.pdf -o output")
		fmt.Fprintln(flag.CommandLine.Output(), "  ./pdf-tool -i input.pdf -o output -f jpg -dpi 450")
		fmt.Fprintln(flag.CommandLine.Output(), "  ./pdf-tool -i input.pdf -o output -l -m-json")
		fmt.Fprintln(flag.CommandLine.Output(), "  ./pdf-tool -i input.pdf -o output -l -m-json -t")
		fmt.Fprintln(flag.CommandLine.Output(), "  ./pdf-tool -i input.pdf -o output -l -m")
		fmt.Fprintln(flag.CommandLine.Output(), "  ./pdf-tool -i input.pdf -o output -l -t")
		fmt.Fprintln(flag.CommandLine.Output(), "  ./pdf-tool -merge -merge-dir /path/to/pdfs -o merged.pdf")
		fmt.Fprintln(flag.CommandLine.Output(), "  ./pdf-tool -merge -merge-dir /path/to/pdfs -o merged.pdf -merge-chunk-size 20")
		fmt.Fprintln(flag.CommandLine.Output(), "  ./pdf-tool -merge -merge-inputs a.pdf,b.pdf,c.pdf -o merged.pdf -l")
		fmt.Fprintln(flag.CommandLine.Output(), "  ./pdf-tool -merge -merge-dir /path/to/pdfs -o merged.pdf -p")
		fmt.Fprintln(flag.CommandLine.Output(), "  ./pdf-tool -merge -merge-dir /path/to/pdfs -o merged.pdf -p -l")
	}
	flag.Parse()

	debugLogsEnabled = *logEnabled
	imageMetaEnabled = *metaEnabled
	imageMetaJSONEnabled = *metaJSONEnabled
	if debugLogsEnabled {
		log.SetOutput(os.Stderr)
	} else {
		log.SetOutput(io.Discard)
	}
	log.SetFlags(0)
	globalImageMetaCollector = newImageMetaCollector(debugLogsEnabled && (imageMetaEnabled || imageMetaJSONEnabled), imageMetaJSONEnabled)

	if *mergeEnabled {
		if err := mergePDFs(*mergeInputDir, *mergeInputList, *mergeGlob, *outputDir, *mergeChunkSize, *mergeDivider, *progressEnabled); err != nil {
			fmt.Fprintf(os.Stderr, "PDF 合并失败：%v\n", err)
			os.Exit(1)
		}
		globalImageMetaCollector.flush()
		return
	}

	// 入口只负责参数解析、输出目录准备和调用核心转换逻辑。
	if err := os.MkdirAll(*outputDir, 0755); err != nil {
		fmt.Fprintf(os.Stderr, "创建输出目录失败：%v\n", err)
		os.Exit(1)
	}

	if err := convertPDFToImages(*inputFile, *outputDir, *format, *dpi, *timing); err != nil {
		fmt.Fprintf(os.Stderr, "PDF 转图片失败：%v\n", err)
		os.Exit(1)
	}
	globalImageMetaCollector.flush()
}

// mergePDFs 负责按参数收集输入文件，并在需要时分批合并，避免一次性处理过多文件。
func mergePDFs(inputDir, inputList, globPattern, outputFile string, chunkSize int, dividerPage, progressEnabled bool) error {
	files, err := collectMergeInputs(inputDir, inputList, globPattern)
	if err != nil {
		return err
	}
	if len(files) == 0 {
		return fmt.Errorf("no pdf files found for merge")
	}

	log.Printf("merge: start files=%d output=%s", len(files), outputFile)

	if chunkSize < 2 {
		chunkSize = len(files)
	}

	outDir := filepath.Dir(outputFile)
	if outDir != "." && outDir != "" {
		if err := os.MkdirAll(outDir, 0755); err != nil {
			return fmt.Errorf("create output directory: %w", err)
		}
	}

	traceProgress(progressEnabled, 0)
	if len(files) <= chunkSize {
		log.Printf("merge: single pass files=%d", len(files))
		if err := api.MergeCreateFile(files, outputFile, dividerPage, nil); err != nil {
			return fmt.Errorf("merge pdfs: %w", err)
		}
		log.Printf("merge: done output=%s", outputFile)
		traceProgress(progressEnabled, 100)
		return nil
	}

	tempDir, err := os.MkdirTemp(outDir, "pdf-tool-merge-*")
	if err != nil {
		return fmt.Errorf("create temp dir: %w", err)
	}
	defer os.RemoveAll(tempDir)

	chunkFiles := make([]string, 0, (len(files)+chunkSize-1)/chunkSize)
	for index := 0; index < len(files); index += chunkSize {
		end := index + chunkSize
		if end > len(files) {
			end = len(files)
		}
		log.Printf("merge: chunk %d start files=%d", len(chunkFiles)+1, end-index)
		chunkOut := filepath.Join(tempDir, fmt.Sprintf("chunk_%04d.pdf", len(chunkFiles)+1))
		if err := api.MergeCreateFile(files[index:end], chunkOut, dividerPage, nil); err != nil {
			return fmt.Errorf("merge chunk %d: %w", len(chunkFiles)+1, err)
		}
		chunkFiles = append(chunkFiles, chunkOut)
		log.Printf("merge: chunk %d done output=%s", len(chunkFiles), chunkOut)
		progress := len(chunkFiles) * 100 / ((len(files) + chunkSize - 1) / chunkSize)
		if progress > 99 {
			progress = 99
		}
		traceProgress(progressEnabled, progress)
	}

	log.Printf("merge: final pass chunks=%d", len(chunkFiles))
	if err := api.MergeCreateFile(chunkFiles, outputFile, dividerPage, nil); err != nil {
		return fmt.Errorf("merge final output: %w", err)
	}
	log.Printf("merge: done output=%s", outputFile)
	traceProgress(progressEnabled, 100)
	return nil
}

// collectMergeInputs 根据目录或显式列表收集合并输入，并保持稳定排序。
func collectMergeInputs(inputDir, inputList, globPattern string) ([]string, error) {
	if strings.TrimSpace(inputList) != "" {
		parts := strings.FieldsFunc(inputList, func(r rune) bool {
			return r == ',' || r == '\n' || r == '\r' || r == ';'
		})
		files := make([]string, 0, len(parts))
		for _, part := range parts {
			path := strings.TrimSpace(part)
			if path == "" {
				continue
			}
			files = append(files, path)
		}
		return files, nil
	}

	if strings.TrimSpace(inputDir) == "" {
		return nil, fmt.Errorf("merge mode requires -merge-dir or -merge-inputs")
	}
	pattern := globPattern
	if strings.TrimSpace(pattern) == "" {
		pattern = "*.pdf"
	}
	matches, err := filepath.Glob(filepath.Join(inputDir, pattern))
	if err != nil {
		return nil, fmt.Errorf("glob merge inputs: %w", err)
	}
	sort.Slice(matches, func(i, j int) bool {
		return naturalLess(filepath.Base(matches[i]), filepath.Base(matches[j]))
	})
	return matches, nil
}

var naturalTokenPattern = regexp.MustCompile(`\d+|\D+`)

func traceProgress(enabled bool, progress int) {
	if !enabled {
		return
	}
	if progress < 0 {
		progress = 0
	}
	if progress > 100 {
		progress = 100
	}
	fmt.Fprintln(os.Stderr, progress)
}

func naturalLess(left, right string) bool {
	leftParts := naturalTokenPattern.FindAllString(left, -1)
	rightParts := naturalTokenPattern.FindAllString(right, -1)
	for index := 0; index < len(leftParts) && index < len(rightParts); index++ {
		leftPart := leftParts[index]
		rightPart := rightParts[index]
		leftIsNumber := leftPart[0] >= '0' && leftPart[0] <= '9'
		rightIsNumber := rightPart[0] >= '0' && rightPart[0] <= '9'
		if leftIsNumber && rightIsNumber {
			leftTrimmed := strings.TrimLeft(leftPart, "0")
			rightTrimmed := strings.TrimLeft(rightPart, "0")
			if leftTrimmed == "" {
				leftTrimmed = "0"
			}
			if rightTrimmed == "" {
				rightTrimmed = "0"
			}
			if len(leftTrimmed) != len(rightTrimmed) {
				return len(leftTrimmed) < len(rightTrimmed)
			}
			if leftTrimmed != rightTrimmed {
				return leftTrimmed < rightTrimmed
			}
			if len(leftPart) != len(rightPart) {
				return len(leftPart) < len(rightPart)
			}
			continue
		}
		if leftPart != rightPart {
			return leftPart < rightPart
		}
	}
	return len(leftParts) < len(rightParts)
}

// convertPDFToImages 是整个程序的核心调度器。
// 它会先判断 PDF 是否存在裁剪路径，再决定：
// 1. 直接从对象流里提取嵌入图片；
// 2. 先渲染整页，再通过连通域分析把主体区域裁出来。
// 这样做的目的，是在“速度”和“兼容性”之间做分流。
func convertPDFToImages(inputFile, outputDir, format string, dpi float64, timing bool) error {
	// 先做 PDF 级别的静态分析，再决定走“直接提取”还是“渲染后裁剪”路径。
	file, err := os.Open(inputFile)
	if err != nil {
		return fmt.Errorf("open PDF: %w", err)
	}
	defer file.Close()

	conf := model.NewDefaultConfiguration()
	conf.Cmd = model.EXTRACTIMAGES
	ctx, err := api.ReadValidateAndOptimize(file, conf)
	if err != nil {
		return fmt.Errorf("read PDF context: %w", err)
	}

	format = strings.ToLower(strings.TrimSpace(format))
	if format != "png" && format != "jpg" && format != "jpeg" {
		return fmt.Errorf("unsupported output format %q", format)
	}

	// 先扫内容流里是否存在裁剪路径指令。
	// 如果没有，说明页面大概率只是普通图片或简单内容，
	// 这类文件通常直接抽取对象会比整页渲染更快。
	hasClipPath, err := pdfHasClipPath(ctx)
	if err != nil {
		return fmt.Errorf("inspect clip path: %w", err)
	}
	traceTiming(timing, "clip-path=%v", hasClipPath)
	hasMultipleImageObjects, err := pdfHasMultipleImageObjects(ctx)
	if err != nil {
		return fmt.Errorf("inspect image objects: %w", err)
	}
	traceTiming(timing, "multi-image-objects=%v", hasMultipleImageObjects)

	if !hasClipPath && !hasMultipleImageObjects {
		// 分支 1：没有裁剪路径。
		// 这类 PDF 通常更接近“图片资源直出”的场景，因此优先走对象提取。
		// 这样可以避免整页渲染造成的耗时，也避免裁剪阈值误差。
		return extractDirectImages(ctx, inputFile, outputDir, timing)
	}

	// 分支 2：存在裁剪路径。
	// 这说明页面可见结果可能依赖裁剪框、遮罩或复杂绘图步骤，
	// 直接抽取原始图片对象很可能和最终画面不一致。
	// 走到这里表示页面内容可能使用了裁剪、蒙版或复杂绘制，
	// 直接从对象流里抠图很容易漏掉最终可见区域。
	doc, err := fitz.New(inputFile)
	if err != nil {
		return fmt.Errorf("open PDF for render crop: %w", err)
	}
	muteFitzWarnings(doc)
	defer doc.Close()

	pageCount := doc.NumPage()
	if pageCount == 0 {
		return fmt.Errorf("PDF has no pages")
	}

	totalSaved := 0
	for pageIndex := 0; pageIndex < pageCount; pageIndex++ {
		pageStart := time.Now()
		traceTiming(timing, "page %d start", pageIndex+1)

		renderStart := time.Now()
		img, err := doc.ImageDPI(pageIndex, dpi)
		if err != nil {
			return fmt.Errorf("render page %d: %w", pageIndex+1, err)
		}
		traceTiming(timing, "page %d render=%s", pageIndex+1, time.Since(renderStart))

		// 对渲染结果做连通域分析。
		// 这里不是精确 OCR 或版面分析，而是用背景阈值把“主要可见块”先找出来。
		analyzeStart := time.Now()
		crops, err := findLargestRegions(img, 100)
		if err != nil {
			return fmt.Errorf("analyze page %d: %w", pageIndex+1, err)
		}
		traceTiming(timing, "page %d analyze=%s candidates=%d", pageIndex+1, time.Since(analyzeStart), len(crops))
		if len(crops) == 0 {
			return fmt.Errorf("page %d contains no crop candidates", pageIndex+1)
		}

		for cropIndex, cropRect := range crops {
			cropStart := time.Now()
			cropped := cropImage(img, cropRect)
			traceTiming(timing, "page %d crop %d crop-image=%s rect=%dx%d", pageIndex+1, cropIndex+1, time.Since(cropStart), cropRect.Dx(), cropRect.Dy())

			// 每个候选区域都单独落盘，方便后续对比哪个区域识别有偏差，
			// 也方便你定位到底是“裁剪错了”还是“页面本身就有多个主体”。
			writeStart := time.Now()
			outputPath := filepath.Join(outputDir, fmt.Sprintf("page_%03d_image_%03d.%s", pageIndex+1, cropIndex+1, outputExtension(format)))
			file, err := os.Create(outputPath)
			if err != nil {
				return fmt.Errorf("create output file: %w", err)
			}

			switch format {
			case "png":
				err = encodePNG(file, cropped)
			case "jpg", "jpeg":
				err = jpeg.Encode(file, cropped, &jpeg.Options{Quality: 95})
			}

			closeErr := file.Close()
			if err == nil {
				err = closeErr
			}
			if err != nil {
				return fmt.Errorf("save page %d crop %d: %w", pageIndex+1, cropIndex+1, err)
			}
			traceImageMeta(imageMetaRecord{
				Type:   "image-meta",
				Source: "render-crop",
				Page:   pageIndex + 1,
				Index:  cropIndex + 1,
				Width:  cropRect.Dx(),
				Height: cropRect.Dy(),
				Ext:    outputExtension(format),
				Time:   time.Since(cropStart).String(),
				Path:   outputPath,
			})
			traceTiming(timing, "page %d crop %d write=%s path=%s", pageIndex+1, cropIndex+1, time.Since(writeStart), outputPath)
			totalSaved++
		}
		traceTiming(timing, "page %d total=%s", pageIndex+1, time.Since(pageStart))
	}

	if totalSaved == 0 {
		return fmt.Errorf("no image crops were saved")
	}

	return nil
}

// extractDirectImages 走的是“对象级提取”路径。
// 它适用于 PDF 中已经嵌入了可直接输出的图片资源：
// - JPEG / JPEG2000 之类的编码流可以直接复制；
// - 8-bit RGB / Gray 可以快速重建成 PNG；
// - 其他复杂颜色空间或位深会自动回退。
func extractDirectImages(ctx *model.Context, inputFile, outputDir string, timing bool) error {
	start := time.Now()
	traceTiming(timing, "direct-extract start")
	inputStem := strings.TrimSuffix(filepath.Base(inputFile), filepath.Ext(inputFile))
	// pageDigits 用来统一输出文件名的页码宽度，保证排序时自然对齐。
	pageDigits := len(strconv.Itoa(ctx.PageCount))
	totalWritten := 0

	// 逐页扫描对象号，页面内的图片对象会进入并发提取。
	for pageNr := 1; pageNr <= ctx.PageCount; pageNr++ {
		pageNr := pageNr
		pageStart := time.Now()
		objNrs := pdfcpu.ImageObjNrs(ctx, pageNr)
		sort.Ints(objNrs)
		if len(objNrs) == 0 {
			// 分支：当前页没有任何图片对象。
			// 这不是错误，只是说明这一页不需要导出图片，直接跳过即可。
			traceTiming(timing, "direct-extract page %d=%s images=0", pageNr, time.Since(pageStart))
			continue
		}

		// workerCount 直接跟当前可用的调度并行度对齐，避免图片对象多时串行写盘。
		workerCount := runtime.GOMAXPROCS(0)
		if workerCount > len(objNrs) {
			workerCount = len(objNrs)
		}
		if workerCount < 1 {
			// 分支：并行度被压到 0 的极端情况。
			// 这里强制修正为 1，避免后面没有 worker 可以消费任务。
			workerCount = 1
		}

		// 用 worker 池并发写出同一页内的多个图片对象。
		// 这里并发的是“对象级提取”，不是“页级渲染”，因此 IO 占比更高。
		jobs := make(chan int)
		errCh := make(chan error, 1)
		var wg sync.WaitGroup
		var writtenMu sync.Mutex
		pageWritten := 0

		for workerIndex := 0; workerIndex < workerCount; workerIndex++ {
			wg.Add(1)
			go func() {
				defer wg.Done()
				for objNr := range jobs {
					if err := writeDirectImage(ctx, pageNr, objNr, inputStem, pageDigits, outputDir, timing); err != nil {
						select {
						case errCh <- err:
						default:
						}
						continue
					}

					writtenMu.Lock()
					pageWritten++
					writtenMu.Unlock()
				}
			}()
		}

		for _, objNr := range objNrs {
			jobs <- objNr
		}
		close(jobs)
		wg.Wait()

		select {
		case err := <-errCh:
			return err
		default:
		}

		totalWritten += pageWritten

		traceTiming(timing, "direct-extract page %d=%s images=%d", pageNr, time.Since(pageStart), pageWritten)
	}

	if totalWritten == 0 {
		return fmt.Errorf("no images were written")
	}
	traceTiming(timing, "direct-extract total=%s", time.Since(start))
	return nil
}

// writeDirectImage 负责把单个图片对象落盘。
// 它先尝试快速路径；若快速路径条件不成立，再退回到 pdfcpu 的通用解码。
func writeDirectImage(ctx *model.Context, pageNr, objNr int, inputStem string, pageDigits int, outputDir string, timing bool) error {
	objStart := time.Now()
	imageObj := ctx.Optimize.ImageObjects[objNr]
	if imageObj == nil || imageObj.ImageDict == nil {
		// 这个对象不是完整图片，直接跳过。
		// 例如它可能只是一个引用节点、占位对象，或者缺少真正的图像字典。
		return nil
	}

	resourceID := ""
	if pageNr-1 < len(imageObj.ResourceNames) {
		resourceID = imageObj.ResourceNames[pageNr-1]
	}

	if ok, err := writeDirectImageFast(ctx, imageObj.ImageDict, objNr, inputStem, pageDigits, pageNr, resourceID, outputDir, objStart, timing); ok {
		return err
	}

	// 分支：快速路径没有命中。
	// 说明当前对象不适合“直接复制字节”或“手工重建像素”，
	// 接下来交给 pdfcpu 的通用提取逻辑兜底。
	// 快路径失败时，退回到 pdfcpu 的通用解码逻辑。
	// 这个回退点很重要：它保证复杂 PDF 仍然能产出结果，只是慢一点。
	decodeStart := time.Now()
	img, err := pdfcpu.ExtractImage(ctx, imageObj.ImageDict, false, resourceID, objNr, false)
	if err != nil {
		return fmt.Errorf("extract page %d obj %d: %w", pageNr, objNr, err)
	}
	traceTiming(timing, "direct-extract page %d obj %d fallback-extract=%s", pageNr, objNr, time.Since(decodeStart))
	if img == nil || img.Reader == nil || img.Thumb {
		return nil
	}

	qual := img.Name
	if qual == "" {
		qual = "image"
	}
	outputExt := normalizeOutputImageExt(img.FileType)
	fileName := fmt.Sprintf("%s_%0*d_%s_obj%d.%s", inputStem, pageDigits, pageNr, qual, objNr, outputExt)
	outPath := filepath.Join(outputDir, fileName)
	metaWidth, metaHeight := resolveImageDimensions(imageObj.ImageDict, img.Width, img.Height)
	traceImageMeta(imageMetaRecord{
		Type:   "image-meta",
		Source: "direct-fallback",
		Page:   pageNr,
		Object: objNr,
		Width:  metaWidth,
		Height: metaHeight,
		Ext:    outputExt,
		Time:   time.Since(objStart).String(),
		Path:   outPath,
	})

	outFile, err := os.Create(outPath)
	if err != nil {
		return fmt.Errorf("create output file: %w", err)
	}
	writeStart := time.Now()
	if normalizeOutputImageExt(img.FileType) == "png" && strings.EqualFold(strings.TrimSpace(img.FileType), "jpx") {
		content, err := io.ReadAll(img.Reader)
		if err != nil {
			_ = outFile.Close()
			return fmt.Errorf("read image %s: %w", outPath, err)
		}
		_ = outFile.Close()
		if err := writeJPXAsPNG(content, outPath, timing); err != nil {
			return err
		}
		traceTiming(timing, "direct-extract page %d obj %d fallback-write=%s", pageNr, objNr, time.Since(writeStart))
		return nil
	}
	if outputExt == "png" && !isDirectCopyableImageType(img.FileType) {
		decodedImg, decodeErr := decodeImageForOutput(img.FileType, img.Reader)
		if decodeErr != nil {
			_ = outFile.Close()
			return fmt.Errorf("decode image %s: %w", outPath, decodeErr)
		}
		if err := encodePNG(outFile, decodedImg); err != nil {
			_ = outFile.Close()
			return fmt.Errorf("write image %s: %w", outPath, err)
		}
	} else {
		if _, err := io.Copy(outFile, img.Reader); err != nil {
			_ = outFile.Close()
			return fmt.Errorf("write image %s: %w", outPath, err)
		}
	}
	if err := outFile.Close(); err != nil {
		return fmt.Errorf("close output file: %w", err)
	}
	traceTiming(timing, "direct-extract page %d obj %d fallback-write=%s", pageNr, objNr, time.Since(writeStart))
	return nil
}

// writeDirectImageFast 尝试绕过通用图像解码，直接把图片流写出来。
// 返回值中的 bool 表示“是否真的走了快速写出路径”。
// false != error：
// - false, nil 代表条件不满足，应该回退；
// - false, err 代表快速路径在处理中出错；
// - true, nil 代表已经成功写盘。
func writeDirectImageFast(ctx *model.Context, sd *types.StreamDict, objNr int, inputStem string, pageDigits, pageNr int, resourceID, outputDir string, startedAt time.Time, timing bool) (bool, error) {
	if sd == nil {
		// 分支：没有 stream dict，说明这个对象根本不符合图片流处理条件。
		return false, nil
	}

	w := sd.IntEntry("Width")
	h := sd.IntEntry("Height")

	// 先判断是否是已经编码好的图片流，尽量避免重新解码和重建像素。
	// 这一步的目标是尽量把“复制字节”替换掉“重建图像”。
	lastFilter := ""
	if len(sd.FilterPipeline) > 0 {
		lastFilter = sd.FilterPipeline[len(sd.FilterPipeline)-1].Name
	}

	// Direct copy for already encoded image streams.
	if lastFilter == filter.JPX {
		if resourceID == "" {
			resourceID = "image"
		}
		fileName := fmt.Sprintf("%s_%0*d_%s_obj%d.png", inputStem, pageDigits, pageNr, resourceID, objNr)
		outPath := filepath.Join(outputDir, fileName)
		traceImageMeta(imageMetaRecord{
			Type:   "image-meta",
			Source: "direct-fast",
			Page:   pageNr,
			Object: objNr,
			Width:  *w,
			Height: *h,
			Ext:    "png",
			Time:   time.Since(startedAt).String(),
			Path:   outPath,
		})
		if err := writeJPXAsPNG(sd.Content, outPath, timing); err != nil {
			return false, err
		}
		return true, nil
	}

	if lastFilter == filter.DCT {
		// 分支：图片流本身已经是压缩后的成熟编码格式。
		// 这种情况最理想的做法就是尽量不碰像素，只做字节级输出。
		// DCT(JPEG) 可以直接落盘；但 CMYK JPEG 不适合直接当作普通 jpg 输出，
		// 因为颜色解释会出错，所以这里保守回退。
		if lastFilter == filter.DCT && sd.CSComponents == 4 {
			// 分支：CMYK JPEG。
			// 由于颜色空间解释不确定，宁可回退到通用路径，也不要写出“看起来像错色”的图片。
			return false, nil
		}

		decodeStart := time.Now()
		if err := sd.Decode(); err != nil {
			return false, fmt.Errorf("decode page %d obj %d: %w", pageNr, objNr, err)
		}
		traceTiming(timing, "direct-extract page %d obj %d raw-decode=%s", pageNr, objNr, time.Since(decodeStart))

		ext := "jpg"
		if lastFilter == filter.JPX {
			ext = "jpx"
		}
		if resourceID == "" {
			resourceID = "image"
		}
		fileName := fmt.Sprintf("%s_%0*d_%s_obj%d.%s", inputStem, pageDigits, pageNr, resourceID, objNr, ext)
		outPath := filepath.Join(outputDir, fileName)
		traceImageMeta(imageMetaRecord{
			Type:   "image-meta",
			Source: "direct-fast",
			Page:   pageNr,
			Object: objNr,
			Width:  *w,
			Height: *h,
			Ext:    ext,
			Time:   time.Since(startedAt).String(),
			Path:   outPath,
		})
		writeStart := time.Now()
		if err := os.WriteFile(outPath, sd.Content, 0644); err != nil {
			return false, fmt.Errorf("write image %s: %w", outPath, err)
		}
		traceTiming(timing, "direct-extract page %d obj %d raw-write=%s", pageNr, objNr, time.Since(writeStart))
		return true, nil
	}

	// 下面这段只处理 8-bit RGB / Gray，保证我们自己拼像素时数据布局是确定的。
	// 只要颜色空间、位深或遮罩条件不满足，就宁可回退，不做“猜测式输出”。
	decodeStart := time.Now()
	if err := sd.Decode(); err != nil {
		return false, fmt.Errorf("decode page %d obj %d: %w", pageNr, objNr, err)
	}
	traceTiming(timing, "direct-extract page %d obj %d decode=%s", pageNr, objNr, time.Since(decodeStart))

	csStart := time.Now()
	cs, err := pdfcpu.ColorSpaceString(ctx, sd)
	if err != nil {
		return false, fmt.Errorf("colorspace page %d obj %d: %w", pageNr, objNr, err)
	}
	traceTiming(timing, "direct-extract page %d obj %d colorspace=%s", pageNr, objNr, time.Since(csStart))

	bpc := 0
	if v := sd.IntEntry("BitsPerComponent"); v != nil {
		bpc = *v
	}

	if bpc != 8 || (cs != model.DeviceRGBCS && cs != model.DeviceGrayCS) {
		// 分支：图像不满足快速重建条件。
		// 常见原因包括：CMYK、索引色、16-bit、或者其他复杂色彩空间。
		// 颜色空间或位深不符合当前快速重建条件，回退到通用路径。
		// 这通常是 CMYK、索引色、位深不是 8 的 PDF。
		return false, nil
	}

	if w == nil || h == nil {
		return false, nil
	}

	softMaskStart := time.Now()
	softMask, err := extractSoftMask(ctx, sd, objNr, *w, *h, timing, pageNr)
	if err != nil {
		return false, err
	}
	traceTiming(timing, "direct-extract page %d obj %d softmask=%s present=%v", pageNr, objNr, time.Since(softMaskStart), softMask != nil)

	if softMask == nil {
		// 分支：主图像声明了软遮罩，但我们没有拿到可用的 SMask 内容。
		// 这时继续写图会造成透明度缺失，所以直接回退。
		// 如果存在 SMask 但未能成功解出，就不强行继续，避免透明信息丢失。
		// 这类图片如果硬写出来，视觉结果可能比回退路径更差。
		if o, _ := sd.Find("SMask"); o != nil {
			return false, nil
		}
	}

	if resourceID == "" {
		resourceID = "image"
	}
	fileName := fmt.Sprintf("%s_%0*d_%s_obj%d.png", inputStem, pageDigits, pageNr, resourceID, objNr)
	outPath := filepath.Join(outputDir, fileName)
	traceImageMeta(imageMetaRecord{
		Type:   "image-meta",
		Source: "direct-fast",
		Page:   pageNr,
		Object: objNr,
		Width:  *w,
		Height: *h,
		Ext:    "png",
		Time:   time.Since(startedAt).String(),
		Path:   outPath,
	})
	outFile, err := os.Create(outPath)
	if err != nil {
		return false, fmt.Errorf("create output file: %w", err)
	}
	defer outFile.Close()

	img := image.NewNRGBA(image.Rect(0, 0, *w, *h))
	b := sd.Content
	paintStart := time.Now()
	if cs == model.DeviceGrayCS {
		// 分支：灰度图。
		// 这一支只需要一个灰度通道，所以像素重建逻辑相对简单。
		// 灰度图逐像素扩展为 RGBA，透明度来自 soft mask（如果有）。
		// 这样输出的是标准 PNG，而不是依赖外部解释器的灰度流。
		if len(b) < (*w * *h) {
			return false, fmt.Errorf("gray image obj %d corrupt", objNr)
		}
		i := 0
		for y := 0; y < *h; y++ {
			for x := 0; x < *w; x++ {
				alpha := uint8(255)
				if softMask != nil {
					alpha = softMask[y**w+x]
				}
				v := b[i]
				img.SetNRGBA(x, y, color.NRGBA{R: v, G: v, B: v, A: alpha})
				i++
			}
		}
	} else {
		// 分支：RGB 图。
		// 这意味着我们要按 3 字节一组重建像素，并保持原始通道顺序。
		// RGB 图同样逐像素写入，保证输出文件与原始像素顺序一致。
		// 这里不做额外颜色变换，默认保留原始 RGB 顺序。
		if len(b) < 3*(*w**h) {
			return false, fmt.Errorf("rgb image obj %d corrupt", objNr)
		}
		i := 0
		for y := 0; y < *h; y++ {
			for x := 0; x < *w; x++ {
				alpha := uint8(255)
				if softMask != nil {
					alpha = softMask[y**w+x]
				}
				img.SetNRGBA(x, y, color.NRGBA{R: b[i], G: b[i+1], B: b[i+2], A: alpha})
				i += 3
			}
		}
	}
	traceTiming(timing, "direct-extract page %d obj %d paint=%s", pageNr, objNr, time.Since(paintStart))

	encodeStart := time.Now()
	enc := png.Encoder{CompressionLevel: png.NoCompression}
	if err := enc.Encode(outFile, img); err != nil {
		return false, fmt.Errorf("encode image %s: %w", outPath, err)
	}
	traceTiming(timing, "direct-extract page %d obj %d encode=%s", pageNr, objNr, time.Since(encodeStart))
	if err := outFile.Close(); err != nil {
		return false, fmt.Errorf("close output file: %w", err)
	}
	return true, nil
}

func encodePNG(w io.Writer, img image.Image) error {
	enc := png.Encoder{CompressionLevel: png.NoCompression}
	return enc.Encode(w, img)
}

// extractSoftMask 读取并解码 SMask。
// 它只接受与主图像尺寸严格一致、且位深为 8 的软遮罩，
// 这样可以避免把错误尺寸的透明信息错误叠到图片上。
func extractSoftMask(ctx *model.Context, sd *types.StreamDict, objNr, w, h int, timing bool, pageNr int) ([]byte, error) {
	start := time.Now()
	o, _ := sd.Find("SMask")
	if o == nil {
		// 分支：没有软遮罩。
		// 这种情况下 alpha 直接视为 255，不需要额外处理。
		// 没有软遮罩时，直接返回空，外层会继续当前图像输出。
		return nil, nil
	}

	sm, _, err := ctx.XRefTable.DereferenceStreamDict(o)
	if err != nil {
		return nil, err
	}
	if sm == nil {
		return nil, nil
	}
	if err := sm.Decode(); err != nil {
		return nil, err
	}
	bpc := sm.IntEntry("BitsPerComponent")
	if bpc == nil || *bpc != 8 {
		// 分支：软遮罩不是 8-bit。
		// 当前快速路径只接受标准 8-bit alpha，其他情况直接放弃。
		return nil, nil
	}
	if len(sm.Content) != w*h {
		// 分支：软遮罩尺寸不对。
		// 一旦宽高不一致，alpha 和像素就会错位，所以不能继续用。
		// 软遮罩大小和图像尺寸不匹配，说明不能安全使用。
		// 这种情况如果继续合成，alpha 会错位。
		return nil, nil
	}
	traceTiming(timing, "direct-extract page %d obj %d softmask-decode=%s", pageNr, objNr, time.Since(start))
	return sm.Content, nil
}

// pdfHasClipPath 会扫描所有页面的内容流。
// 只要任意页面出现裁剪路径，就说明“直接抽图”可能不可靠，
// 需要切到渲染后裁剪的策略。
func pdfHasClipPath(ctx *model.Context) (bool, error) {
	// 只要任意页面的内容流里出现裁剪路径，就切换到渲染+裁剪策略。
	for pageNr := 1; pageNr <= ctx.PageCount; pageNr++ {
		pageDict, _, _, err := ctx.PageDict(pageNr, false)
		if err != nil {
			return false, fmt.Errorf("page %d dict: %w", pageNr, err)
		}
		content, err := ctx.PageContent(pageDict, pageNr)
		if err != nil {
			if err == model.ErrNoContent {
				// 分支：当前页没有内容流。
				// 这是合法情况，说明这一页可能是空白页，直接扫描下一页。
				continue
			}
			return false, fmt.Errorf("page %d content: %w", pageNr, err)
		}
		if hasClipOperator(content) {
			return true, nil
		}
	}
	return false, nil
}

// pdfHasMultipleImageObjects 会检查是否存在“同一页里有多个图片对象”的情况。
// 这类 PDF 往往不适合只按对象级别直取，因为直取只能拿到嵌入对象，
// 无法反映页面最终渲染出来的图片实例数。
func pdfHasMultipleImageObjects(ctx *model.Context) (bool, error) {
	for pageNr := 1; pageNr <= ctx.PageCount; pageNr++ {
		objNrs := pdfcpu.ImageObjNrs(ctx, pageNr)
		if len(objNrs) > 1 {
			return true, nil
		}
	}
	return false, nil
}

// hasClipOperator 不是一个严格的 PDF 语法解析器，
// 它只是做一个快速启发式判断：既要看到裁剪指令，也要看到普通绘图指令。
// 这样可以减少把文本内容或无关字节误判成裁剪路径的概率。
func hasClipOperator(content []byte) bool {
	// 一些 PDF 会把很多图片放在重复的矩形裁剪框里，这种情况更适合直取。
	// 只有裁剪命中不多、而且同时存在普通绘图指令时，才按“需要裁剪”处理。
	if len(clipOperatorPattern.FindAllIndex(content, -1)) > maxClipOperatorCountForCrop {
		return false
	}
	return clipOperatorPattern.Match(content) && drawingOperatorPattern.Match(content)
}

var clipOperatorPattern = regexp.MustCompile(`(^|[^A-Za-z0-9_/])W\*?([^A-Za-z0-9_]|$)`)

var drawingOperatorPattern = regexp.MustCompile(`(^|[^A-Za-z0-9_/])(m|l|c|v|y|h|S|s|f|F|B|b|B\*|b\*)([^A-Za-z0-9_]|$)`)

const maxClipOperatorCountForCrop = 8

type region struct {
	rect image.Rectangle
	area int
}

const minRegionArea = 50000

// findLargestRegions 从整页渲染结果里提取最大的前景区域。
// 它的假设很简单：
// - 页面大部分背景接近白色；
// - 目标内容在像素上是连通的或者近似连通的；
// - 前景面积越大，越可能是我们想要的图像主体。
func findLargestRegions(img image.Image, maxRegions int) ([]image.Rectangle, error) {
	// 把渲染结果转成 RGBA 后，按背景阈值做 flood fill，提取最大的前景区域。
	rgba := toRGBA(img)
	bounds := rgba.Bounds()
	width := bounds.Dx()
	height := bounds.Dy()
	if width == 0 || height == 0 {
		return nil, fmt.Errorf("empty rendered page")
	}

	visited := make([]bool, width*height)
	regions := make([]region, 0, 16)

	for y := bounds.Min.Y; y < bounds.Max.Y; y++ {
		for x := bounds.Min.X; x < bounds.Max.X; x++ {
			idx := (y-bounds.Min.Y)*width + (x - bounds.Min.X)
			if visited[idx] {
				continue
			}
			if isBackground(rgba.RGBAAt(x, y)) {
				visited[idx] = true
				continue
			}

			rect, area := floodFillRegion(rgba, x, y, visited)
			if area >= minRegionArea {
				regions = append(regions, region{rect: rect, area: area})
			}
		}
	}

	sort.Slice(regions, func(i, j int) bool {
		if regions[i].area == regions[j].area {
			if regions[i].rect.Min.Y == regions[j].rect.Min.Y {
				return regions[i].rect.Min.X < regions[j].rect.Min.X
			}
			return regions[i].rect.Min.Y < regions[j].rect.Min.Y
		}
		return regions[i].area > regions[j].area
	})

	if len(regions) > maxRegions {
		// 分支：前景连通块过多。
		// 这里只保留面积最大的几个，过滤掉页边噪点、小装饰和碎片区域。
		regions = regions[:maxRegions]
	}

	result := make([]image.Rectangle, 0, len(regions))
	for _, region := range regions {
		result = append(result, region.rect)
	}
	return result, nil
}

// floodFillRegion 使用四邻域 flood fill 扫描一个连通块。
// 它返回两个信息：
// - 这个连通块的外接矩形；
// - 这个连通块的像素面积。
// 后续会按面积排序，保留最大的几个区域。
func floodFillRegion(img *image.RGBA, startX, startY int, visited []bool) (image.Rectangle, int) {
	// 标准四邻域 flood fill，记录连通区域的外接矩形和面积。
	bounds := img.Bounds()
	width := bounds.Dx()
	queue := []image.Point{{X: startX, Y: startY}}
	visited[(startY-bounds.Min.Y)*width+(startX-bounds.Min.X)] = true

	minX, maxX := startX, startX
	minY, maxY := startY, startY
	area := 0

	for len(queue) > 0 {
		p := queue[len(queue)-1]
		queue = queue[:len(queue)-1]
		area++

		if p.X < minX {
			minX = p.X
		}
		if p.X > maxX {
			maxX = p.X
		}
		if p.Y < minY {
			minY = p.Y
		}
		if p.Y > maxY {
			maxY = p.Y
		}

		neighbors := []image.Point{
			{X: p.X - 1, Y: p.Y},
			{X: p.X + 1, Y: p.Y},
			{X: p.X, Y: p.Y - 1},
			{X: p.X, Y: p.Y + 1},
		}

		for _, n := range neighbors {
			if n.X < bounds.Min.X || n.X >= bounds.Max.X || n.Y < bounds.Min.Y || n.Y >= bounds.Max.Y {
				// 分支：邻居越界，直接忽略。
				continue
			}
			idx := (n.Y-bounds.Min.Y)*width + (n.X - bounds.Min.X)
			if visited[idx] {
				// 分支：这个像素已经处理过了，避免重复扩展。
				continue
			}
			if isBackground(img.RGBAAt(n.X, n.Y)) {
				// 分支：邻居仍然是背景像素。
				// 只标记，不入队，这样 flood fill 会自然避开白边和留白。
				visited[idx] = true
				continue
			}
			// 分支：邻居属于前景，把它加入连通块继续扩展。
			visited[idx] = true
			queue = append(queue, n)
		}
	}

	return image.Rect(minX, minY, maxX+1, maxY+1), area
}

// cropImage 把指定矩形从原图中裁出来，并统一输出为 RGBA。
// 这样后面的编码逻辑只需要处理一种图像类型，减少分支。
func cropImage(img image.Image, rect image.Rectangle) *image.RGBA {
	// 裁剪时统一转换成 RGBA，避免不同图像类型之间的绘制差异。
	rgba := toRGBA(img)
	crop := image.NewRGBA(image.Rect(0, 0, rect.Dx(), rect.Dy()))
	draw.Draw(crop, crop.Bounds(), rgba, rect.Min, draw.Src)
	return crop
}

func toRGBA(img image.Image) *image.RGBA {
	if rgba, ok := img.(*image.RGBA); ok {
		return rgba
	}
	bounds := img.Bounds()
	rgba := image.NewRGBA(bounds)
	draw.Draw(rgba, bounds, img, bounds.Min, draw.Src)
	return rgba
}

// isBackground 用一个非常宽松的白色阈值判断背景像素。
// 阈值偏高的原因是：我们更愿意把浅灰边缘也算作背景，
// 这样主体区域的外接框会更稳定。
func isBackground(pixel color.RGBA) bool {
	// 这里把接近白色的像素都视为背景，便于把页面上的主体区域分离出来。
	return pixel.R >= 248 && pixel.G >= 248 && pixel.B >= 248
}

func traceTiming(enabled bool, format string, args ...any) {
	if !enabled || !debugLogsEnabled {
		return
	}
	if globalImageMetaCollector != nil && globalImageMetaCollector.enabled {
		return
	}
	msg := fmt.Sprintf("[timing] "+format, args...)
	fmt.Fprintln(os.Stderr, msg)
}

func traceImageMeta(meta imageMetaRecord) {
	if globalImageMetaCollector == nil || !globalImageMetaCollector.enabled {
		return
	}
	globalImageMetaCollector.add(meta)
}

// resolveImageDimensions 尽量补全 pdfcpu 可能缺失的图片宽高。
// 兜底顺序：已解析出的尺寸优先，其次回退到原始 XObject 字典里的 Width/Height。
func resolveImageDimensions(imageDict *types.StreamDict, width, height int) (int, int) {
	if width <= 0 && imageDict != nil {
		if w := imageDict.IntEntry("Width"); w != nil && *w > 0 {
			width = *w
		}
	}
	if height <= 0 && imageDict != nil {
		if h := imageDict.IntEntry("Height"); h != nil && *h > 0 {
			height = *h
		}
	}
	return width, height
}

func outputExtension(format string) string {
	if format == "jpg" {
		return "jpg"
	}
	return format
}

func normalizeOutputImageExt(fileType string) string {
	switch strings.ToLower(strings.TrimSpace(fileType)) {
	case "jpg", "jpeg", "jpe":
		return "jpg"
	case "png":
		return "png"
	default:
		return "png"
	}
}

func decodeImageForOutput(fileType string, reader io.Reader) (image.Image, error) {
	switch strings.ToLower(strings.TrimSpace(fileType)) {
	case "tif", "tiff":
		img, err := tiff.Decode(reader)
		if err != nil {
			return nil, err
		}
		return img, nil
	default:
		img, _, err := image.Decode(reader)
		if err != nil {
			return nil, err
		}
		return img, nil
	}
}

func writeJPXAsPNG(content []byte, outPath string, timing bool) error {
	if err := writeJPXAsPNGNative(content, outPath, timing); err != nil {
		return fmt.Errorf("convert jpx to png: %w", err)
	}
	return nil
}

func isDirectCopyableImageType(fileType string) bool {
	switch strings.ToLower(strings.TrimSpace(fileType)) {
	case "jpg", "jpeg", "jpe", "png":
		return true
	default:
		return false
	}
}
